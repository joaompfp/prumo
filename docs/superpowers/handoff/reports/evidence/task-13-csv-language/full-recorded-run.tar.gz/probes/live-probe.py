"""Controller live acceptance probe. Real f0nix HTTP egress, no cached/fabricated responses."""
import base64
import hashlib
import io
import json
import signal
import subprocess
import sys
import time
import zipfile
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, '/home/joao/projects/prumo-pipeline')
from ingest.db import open_db
from ingest.http import HttpResult
from ingest.rawstore import RawStore
from ingest.registry import load_registry, sync_registry
from ingest.sources.worldbank import WorldBankSource
from ingest.verifiers import register_verifier
from ingest.verifiers.worldbank import WorldBankVerifier
from ingest.verify import replay_item, run_with_refetch

ROOT = Path('/home/joao/.hermes/cache/scratch/prumo-task13-grouped-live')
ROOT.mkdir(exist_ok=False)
START = time.monotonic()
manifest = []


def expired(*_):
    raise TimeoutError('controller whole live acceptance budget 300s exceeded')


signal.signal(signal.SIGALRM, expired)
signal.alarm(300)


class RemoteHttp:
    def get(self, url, params=None, headers=None, timeout=None):
        if len(manifest) >= 40:
            raise RuntimeError('controller HTTP request budget exhausted')
        if manifest:
            time.sleep(1.0)
        n = len(manifest)
        request = {'url': url, 'params': params, 'headers': headers or {},
                   'timeout': min(float(timeout or 15), 15)}
        remote = '''import urllib.request,urllib.parse,urllib.error,json,base64,sys,datetime
r=json.loads(sys.stdin.read());u=r['url']
if r['params']:u+=('&' if '?' in u else '?')+urllib.parse.urlencode(r['params'])
request=urllib.request.Request(u,headers={'User-Agent':'prumo-ingest/1.0 (+https://cae.joao.date)',**r['headers']})
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
try: response=urllib.request.urlopen(request,timeout=r['timeout'])
except urllib.error.HTTPError as e:response=e
with response as s:
 b=s.read(6000001)
 if len(b)>6000000:raise ValueError('response size limit exceeded')
 print(json.dumps({'url':s.url,'status':s.status,'body_base64':base64.b64encode(b).decode('ascii'),'headers':{k:v for k,v in s.headers.items() if k.lower() not in ('set-cookie','cookie','authorization')},'ts_start':start,'ts_end':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
'''
        # stdin is occupied by the request JSON, so supply the program via -c.
        import shlex
        cmd = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=6', 'f0nix',
               'python3 -c ' + shlex.quote(remote)]
        t = time.monotonic()
        rec = {'n': n, 'requested_url': url, 'params': params,
               'egress': 'f0nix', 'started_at': datetime.now(timezone.utc).isoformat()}
        try:
            proc = subprocess.run(cmd, input=json.dumps(request), text=True,
                                  capture_output=True, timeout=min(22, 295-(time.monotonic()-START)))
            if proc.returncode:
                raise RuntimeError(f'HTTP relay failed: {proc.stderr[-1200:]}')
            doc = json.loads(proc.stdout)
            b = base64.b64decode(doc.pop('body_base64'), validate=True)
            p = ROOT / 'http' / f'{n:02d}.body'
            p.parent.mkdir(exist_ok=True)
            p.write_bytes(b)
            rec.update(doc, path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
            return HttpResult(status=doc['status'], body=b, url=doc['url'])
        except Exception as e:
            rec['error'] = repr(e)
            raise
        finally:
            rec['seconds'] = round(time.monotonic()-t, 3)
            manifest.append(rec)
            (ROOT / 'http-manifest.json').write_text(json.dumps(manifest, indent=2))
            print(json.dumps({k: v for k, v in rec.items() if k not in ('headers', 'params')}), flush=True)


specs = [s for s in load_registry('/home/joao/projects/prumo-pipeline/registry/core.yaml')
         if s.active and s.source.name == 'worldbank']
store = RawStore(ROOT / 'raw')
db = open_db(ROOT / 'live.db')
sync_registry(db, specs)
results = []
es_codes = {'NY.GDP.MKTP.KD.ZG', 'SL.UEM.TOTL.ZS'}
requested = []
for language, group_specs, sample_size in [
    ('en', [s for s in specs if s.native_code.split(':')[0] not in es_codes], 1200),
    ('es', [s for s in specs if s.native_code.split(':')[0] in es_codes], 300),
]:
    # Explicit, disjoint dataset groups chosen BEFORE fetching, not automatic fallback.
    v = WorldBankVerifier(csv_language=language)
    register_verifier(v)
    res = run_with_refetch(db, store, WorldBankSource(), v, group_specs, RemoteHttp(),
                          max_attempts=1, size=sample_size)
    results.append({'language': language, 'series_count': len(group_specs),
                    'series_ids': [s.id for s in group_specs], 'result': asdict(res)})
    requested.extend(s.id for s in group_specs)
assert len(requested) == len(set(requested)) == len(specs)
assert set(requested) == {s.id for s in specs}

columns = [r[1] for r in db.conn.execute('PRAGMA table_info(verification_item)')]
items = [dict(zip(columns, r)) for r in db.conn.execute('SELECT * FROM verification_item ORDER BY id')]
(ROOT / 'verification-items.json').write_text(json.dumps(items, indent=2))
report = {'execution': 'fresh live run_with_refetch; source and verifier real HTTP via f0nix; no cached responses',
          'csv_language': 'explicit en/es disjoint datasets, no fallback', 'active_series': len(specs), 'indicators': len({s.native_code.split(':')[0] for s in specs}),
          'datasets': results, 'all_datasets_verified': all(r['result']['state'] == 'verified' for r in results), 'database': str(ROOT / 'live.db'), 'raw_root': str(store.root),
          'series_written': db.conn.execute('SELECT COUNT(DISTINCT series_id) FROM observation').fetchone()[0],
          'served': db.conn.execute('SELECT COUNT(*) FROM served_observation').fetchone()[0],
          'sample_count': len(items), 'sample_matched': sum(r['match'] == 1 for r in items),
          'mismatch_count': sum(r['match'] != 1 for r in items),
          'mismatches': [{k: r[k] for k in ('series_id','period','expected_text','observed_text','note')} for r in items if r['match'] != 1][:5],
          'http_requests': len(manifest), 'seconds': round(time.monotonic()-START, 3),
          'verification': [list(r) for r in db.conn.execute('SELECT * FROM verification')],
          'quarantine_reasons': [list(r) for r in db.conn.execute('SELECT reason,COUNT(*) FROM quarantine GROUP BY reason')]}
archives = {}
for item in items:
    sha = item['evidence_sha256']
    if sha is None:
        continue
    b = store.load(store.root / 'verify-worldbank' / sha[:2] / sha)
    assert hashlib.sha256(b).hexdigest() == sha
    env = json.loads(b)
    assert env['schema'] == 'worldbank-csv-evidence' and env['version'] == 1
    for rec in env['responses']:
        original = base64.b64decode(rec['body_base64'], validate=True)
        assert rec['status'] == 200
        z = zipfile.ZipFile(io.BytesIO(original))
        assert len(z.infolist()) == 3
        body_sha = hashlib.sha256(original).hexdigest()
        assert any(m.get('sha256') == body_sha and m.get('url') == rec['url'] and m.get('status') == rec['status'] for m in manifest)
        archives[sha] = {'body_sha256': body_sha, 'url': rec['url'], 'status': rec['status'], 'zip_members': z.namelist()}
    assert replay_item(db, store, item['id']) == bool(item['match'])
report['offline_evidence_envelopes_recovered'] = len(archives)
report['offline_replayed_items'] = len(items)
(ROOT / 'offline-evidence.json').write_text(json.dumps(archives, indent=2))
(ROOT / 'report.json').write_text(json.dumps(report, indent=2))
db.close()
signal.alarm(0)
print('FINAL_REPORT ' + json.dumps({**report, 'datasets': [{k:v for k,v in g.items() if k != 'series_ids'} for g in report['datasets']]}), flush=True)
