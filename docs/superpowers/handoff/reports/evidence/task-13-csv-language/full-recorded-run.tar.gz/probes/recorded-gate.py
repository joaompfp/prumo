"""Full-scope recorded-response acceptance, explicitly NOT all-source fresh network success."""
import base64
import hashlib
import json
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path
from urllib.parse import urlencode

REPO = Path('/home/joao/projects/prumo-pipeline')
sys.path.insert(0, str(REPO))
from ingest.db import open_db
from ingest.http import HttpResult
from ingest.rawstore import RawStore
from ingest.registry import load_registry, sync_registry
from ingest.sources.worldbank import WorldBankSource
from ingest.verifiers import register_verifier
from ingest.verifiers.worldbank import WorldBankVerifier
from ingest.verify import replay_item, run_with_refetch

ROOT = Path('/home/joao/.hermes/cache/scratch/prumo-task13-recorded-gate')
ES = {'NY.GDP.MKTP.KD.ZG', 'SL.UEM.TOTL.ZS'}
all_specs = [s for s in load_registry(REPO/'registry/core.yaml') if s.active and s.source.name=='worldbank']

if len(sys.argv) == 1:
    ROOT.mkdir(exist_ok=False)
    for lang in ('en','es'):
        subprocess.run([sys.executable,__file__,lang],check=True,timeout=120)
    groups = [json.loads((ROOT/f'{lang}-report.json').read_text()) for lang in ('en','es')]
    db = open_db(ROOT/'recorded.db')
    ids = [s for g in groups for s in g['series_ids']]
    assert len(ids)==len(set(ids))==len(all_specs) and set(ids)=={s.id for s in all_specs}
    store=RawStore(ROOT/'raw')
    items = db.conn.execute('SELECT id,evidence_sha256 FROM verification_item').fetchall()
    for item_id,sha in items:
        assert replay_item(db,store,item_id)
        body=store.load(store.root/'verify-worldbank'/sha[:2]/sha)
        assert hashlib.sha256(body).hexdigest()==sha
        env=json.loads(body)
        for rec in env['responses']:
            assert rec['status']==200 and base64.b64decode(rec['body_base64'],validate=True).startswith(b'PK')
    report={'kind':'FULL-SCOPE RECORDED-RESPONSE GATE, NOT FULL-SOURCE FRESH LIVE ACCEPTANCE',
            'all_verified':all(g['result']['state']=='verified' for g in groups),'active_series':len(all_specs),
            'sample_count':len(items),'matching':db.conn.execute('SELECT COUNT(*) FROM verification_item WHERE match=1').fetchone()[0],
            'series_written':db.conn.execute('SELECT COUNT(DISTINCT series_id) FROM observation').fetchone()[0],
            'observations':db.conn.execute('SELECT COUNT(*) FROM observation').fetchone()[0],
            'quarantined':db.conn.execute('SELECT COUNT(*) FROM quarantine').fetchone()[0],
            'served_in_isolated_test_db':db.conn.execute('SELECT COUNT(*) FROM served_observation').fetchone()[0],
            'offline_replayed_items':len(items),'evidence_envelopes':len({sha for _,sha in items}),
            'groups':groups,'database':str(ROOT/'recorded.db'),'raw_root':str(ROOT/'raw')}
    cols=[r[1] for r in db.conn.execute('PRAGMA table_info(verification_item)')]
    (ROOT/'verification-items.json').write_text(json.dumps([dict(zip(cols,r)) for r in db.conn.execute('SELECT * FROM verification_item ORDER BY id')],indent=2))
    (ROOT/'report.json').write_text(json.dumps(report,indent=2))
    db.close()
    print(json.dumps({**report,'groups':[{k:v for k,v in g.items() if k!='series_ids'} for g in groups]}))
    raise SystemExit()

language=sys.argv[1]
specs=[s for s in all_specs if (s.native_code.split(':')[0] in ES)==(language=='es')]
responses={}
# Real JSON responses from today's fresh all-930 live source fetch, with captured status/URL/hash.
for m in json.loads(Path('/home/joao/.hermes/cache/scratch/prumo-task13-full-live/http-manifest.json').read_text()):
    if m.get('status')==200 and '/country/' in m.get('url',''):
        responses[m['url']]={**m,'provenance':'2026-11-12 fresh JSON HTTP via f0nix, exact stored body'}
# Real original en exports from the earlier 2026-11-12 recovery; no synthesized responses.
for m in json.loads((REPO/'docs/superpowers/handoff/reports/evidence/task-13-csv-recovery/manifest.json').read_text()):
    if m.get('status')==200 and m.get('zip'):
        responses[m['url']]={**m,'path':str(REPO/m['archived_path']),
                             'provenance':'2026-11-12 recorded original publisher ZIP via f0nix, archived exact bytes'}
# Real original es exports with captured actual200 statuses and final URLs.
for m in json.loads(Path('/home/joao/.hermes/cache/scratch/prumo-task13-recovery-controller/manifest.json').read_text()):
    if m.get('status')==200 and m.get('zip'):
        responses[m['url']]={**m,'provenance':'2026-11-12 recorded original es HTTP response via f0nix'}
for m in json.loads(Path('/home/joao/.hermes/cache/scratch/prumo-task13-last-probe/manifest.json').read_text()):
    if m.get('status')==200 and m.get('zip'):
        responses[m['url']]={**m,'provenance':'2026-11-12 recorded original es HTTP response via f0nix'}
used=[]
class RecordedHttp:
    def get(self,url,params=None,headers=None,timeout=None):
        key=url+('?' + urlencode(params) if params else '')
        m=responses[key]
        b=Path(m['path']).read_bytes()
        assert hashlib.sha256(b).hexdigest()==m['sha256']
        used.append({k:v for k,v in m.items() if k!='headers'})
        return HttpResult(m['status'],b,m['url'])

db=open_db(ROOT/'recorded.db');sync_registry(db,specs);v=WorldBankVerifier(csv_language=language)
register_verifier(v)
res=run_with_refetch(db,RawStore(ROOT/'raw'),WorldBankSource(),v,specs,RecordedHttp(),
                     max_attempts=1,size=1200 if language=='en' else 300)
report={'language':language,'series_ids':[s.id for s in specs],'result':asdict(res),
        'sample_matches':[list(r) for r in db.conn.execute('SELECT COUNT(*),SUM(match) FROM verification_item vi JOIN verification v ON v.id=vi.verification_id WHERE v.dataset_run_id=?',(res.run_id,))],
        'request_count':len(used),'note':'recorded original HTTP responses, not a fresh live request'}
(ROOT/f'{language}-requests.json').write_text(json.dumps(used,indent=2))
(ROOT/f'{language}-report.json').write_text(json.dumps(report,indent=2));db.close()
