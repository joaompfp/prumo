# Code quality / security / UX review — Prumo analysis loop L1–L3

Status: **REQUEST_CHANGES**

Scope: read-only review of `/home/joao/projects/prumo-analysis-loop`, diff
`3b29735..HEAD` plus the current uncommitted followups. The spec re-review
(`/home/joao/.hermes/cache/scratch/prumo-analysis-loop-spec-rereview.md`) was treated as
approved input, not re-litigated. No repository file, CMS document, database, test fixture or
deployment was changed. All probes were scoped Python/TestClient probes against temporary
databases; no full suite and no browser suite were run.

## Blocking findings

### B1 — The new readout renders the series unit twice (Medium UX)

Files:
- `tools/charts/src/adapter.js:271-294` (copies `entry.unit` into `row.unit` and
  `payload.display[...]` into `row.value`)
- `tools/charts/src/adapter.js:546-551` (adds an empty `span.chart-readout-unit` with
  `data-unit`)
- `static/css/chart-inspector.css:65-69` (`content: attr(data-unit)` paints that unit)
- `app/interactive.py:213-214` (`_display` already appends the unit to every displayed value)

Reproduction (temporary DB, real route):

```text
/caderno?s=ine.hicp_yoy.PT&s=worldbank.gdp_growth.US
payload series units: ['%', '%']
payload display last row: ['1,8 %', None]   # None is the sparse calendar cell
```

`pointView` therefore produces `row.value = "1,8 %"`. `renderReadout` then inserts a visible
`%` badge from `data-unit` before that value. The rendered row reads:

```text
<swatch> Taxa de variação homóloga do IHPC - Portugal % 1,8 %
```

The same happens for every multi-series/calendar row (`%`, `p.p.`, `index (base …)`, currency
units). The tests assert `row.unit` and `row.value` independently
(`tests/app/test_chart_interaction.py` `_structured`/`_expect_rows` and
`tests/app/test_calendar_interaction.py:229-241`) and do not assert that the unit is absent from
the value, so the duplication is invisible to the suite.

Impact: the central L1 point inspector shows a redundant unit on every line; with long prepared
units (base-100 index labels) the row becomes materially harder to scan. This is a visible UX
regression, not a data/security issue.

Suggested fix: do not render the badge when the displayed value already ends with that unit, or
render the unit badge only for a missing observation (where there is no value to carry it), or
drop the unit from the value string and keep one representation. Whichever is chosen, add one
browser/DOM assertion that the visible row contains the unit once.

### B2 — Paging can reverse the selection order, which reverses card and chart-series order (Medium UX/correctness)

Files:
- `app/templates/search.html:13` (all off-page selected refs become hidden `s` inputs before
  the results)
- `app/templates/_series_results.html:24` (current-page selected refs become checkboxes later in
  DOM order)
- `app/reads.py:1172-1173` (`hidden_refs` excludes only refs visible on the current page)
- `app/notebook.py:28-29` and `:73` (the parser/`catalogue_path` promise first-appearance order
  so reopening an address keeps the reader's order)
- `app/notebook_chart.py:824-828` (`mode="all"` uses `addressed` order as the chart group)
- `app/chart_model.py:640` (pair styles are assigned by position: `("a", "b")`)

Reproduction (patched catalogue with 25 rows; selection `[ES(page 2), DE(page 1)]`):

```text
page 1 form submits: ['ine.hicp_yoy.ES.024', 'ine.hicp_yoy.DE.000']
page 2 form submits: ['ine.hicp_yoy.DE.000', 'ine.hicp_yoy.ES.024']
```

The hidden off-page `s` is first in the form; the checked current-page box is later. Native GET
serialization follows DOM order. After moving to page 2, opening the selection produces the
reversed `s` order. Confirmed at the notebook:

```text
/caderno?s=ine.hicp_yoy.PT&s=worldbank.gdp_growth.US
 series: [('IHPC', 'a', 0), ('PIB EUA', 'b', 0)]
/caderno?s=worldbank.gdp_growth.US&s=ine.hicp_yoy.PT
 series: [('PIB EUA', 'a', 0), ('IHPC', 'b', 0)]
```

So the same two series swap card order and swap the `a`/`b` chart styles (ink/red) after a page
transition. With an explicit `g`, the chart group order is preserved, but the Caderno cards still
reverse. This is not data loss, but it makes a comparison view change meaning after navigation
and contradicts the stated order guarantee.

Suggested fix: carry a validated ordered token (for example a hidden `ordem` of selected ids)
and reorder the server-side selection from it, or canonicalise notebook order independently of
form DOM order and document that choice. Add a regression test that selects a later-page ref
first, an earlier-page ref second, pages back/forward, opens, and asserts the same card and
series order.

## Non-blocking findings

### N1 — The 48-reference UI cliff returns a generic 404 on the next checkbox (Low/Medium UX)

`app/discovery_selection.py:20` and `:45-46` refuse more than 48 raw `s` values; the route
returns the generic 404 before opening the DB (`app/main.py:227-232`). The search form keeps all
result checkboxes enabled at 48 selected references, so checking one more result submits 49 raw
values and loses the page/selection to a 404. There is no visible “48” explanation; the only
warning covers the 12-card Caderno limit.

Reproduction:

```text
GET /pesquisa with 48 x s  -> 200
GET /pesquisa with 49 x s  -> 404
```

The hard ceiling is a spec decision, but the UI can make it unreachable by disabling result
checkboxes and explaining the bound at 48, or the route contract can be revisited. Current
behaviour is a normal-looking control that produces a hard error.

### N2 — Clearing a selection can leave a hidden `grafico=off` for the next selection (Low UX)

`app/main.py:236-251` clears the selection and then calls `read_chart_settings`; stale
`grafico=on&g=…` values are pruned by `without_side`
(`app/notebook_chart.py:312-323`), which turns an explicit group into `mode="off"`. The response
therefore renders a hidden `grafico=off` (`search.html:14`). A reader who clears a selection and
then checks new results and opens the Caderno gets `/caderno?s=…&grafico=off` and no chart.

Confirmed: `GET /pesquisa?s=HICP&grafico=on&g=HICP&limpar=selecao` renders
`name="grafico" value="off"`. This may be the intended “deliberate removal of every side” state;
if so, document it, otherwise suppress the off state when the selection is cleared and let the
new selection choose the default chart again.

### N3 — Dead state/helpers and one brittle reader-copy coupling (Low code quality)

- `app/reads.py:1191` still computes `selection_can_open`, but no production template uses it;
  only tests read it. `app/discovery_selection.py:21` defines unused `MAX_REFERENCES`.
- `app/reads.py:1185-1188` still builds `clear_path`/`prev_path`/`next_path` with `s`, but
  `search.html:86-88` uses only their truthiness and submit buttons; `clear_path` has no search
  template consumer. The old `#discovery-form .button[disabled]` rule
  (`static/css/discovery.css:71`) is now unreachable because the open control is never disabled.
- `_cms_analysis.html:3` and `_notebook_chart.html:7` decide the mixed-frequency caption by
  comparing the translated display string `panel.period_label == …chart_period_mixed`. This is
  exact today but couples a branch to reader copy; a semantic flag on the panel would be safer.
- `static/css/chart-inspector.css:73-76` hardcodes the reader-facing label `"observação: "` in
  CSS rather than `presentation/notebook.py`, and CSS-generated content is inconsistently exposed
  to assistive technology. The native period itself is still text, so this is not a data or
  accessibility blocker, but it is outside the project’s copy-ownership convention.

## Verified in the scoped probes

- **Bounds before DB:** 49 raw or malformed `s` returns 404 before the DB handle; 48 valid refs
  reaches the read layer (503 with a missing DB, 200 with the fixture). The offending value is
  not echoed.
- **Unavailable labels:** withdrawn/inactive refs produce `Referência indisponível` and
  `Indisponível`; neither stored title nor raw id appears in visible text. The id remains only in
  the hidden `s`/remove-control value, which the reader supplied.
- **Open/handoff:** 12 unique refs open with 303; 13 returns 200 with the limit notice and no
  redirect; malformed/stale `g` is pruned; `frequencia_grafico` round-trips through the Caderno
  link without becoming a catalogue `frequencia` filter.
- **Chart settings:** explicit group, scale, window, frequency, transform and base round-trip
  `/caderno` → `/pesquisa` → `/caderno` with the expected values; `grafico=off` and explicit
  empty `grafico=on` both parse and re-render.
- **No-JS/print:** `chart-inspector.css` hides `.chart-controls` until `chart-shell` gains
  `.chart-enhanced`, so the static SVG has no empty control gap; `details.chart-meta` print rules
  are global and cover outside-shell fallbacks. No new finding.
- **Sparse mixed-frequency point handling:** v2 `pointView` reads `cell_periods`/nullable
  `display` and the readout marks a missing row rather than inventing a value; the only issue
  found in that path is the duplicated unit in B1.
- **CMS/statistical scope:** the diff changes presentation/templates/CSS/tests and the
  `Máximo` label; no CMS published config, statistical value or storage path was touched.

## Probe commands (scratch only)

- `/home/joao/projects/prumo-pipeline/.venv-ci/bin/python /home/joao/.hermes/cache/scratch/prumo_review_probe.py`
- Inline TestClient probes for the reverse-order notebook payload and the `limpar=selecao`
  hidden `grafico=off` form.
- A temporary-DB DOM probe using `tests.app.test_discovery_selection._catalogue_row` to render
  page 1/2 and inspect form control order; no repository file was written.

## Recommended gate

Resolve B1 and B2 before calling the L1–L3 integration merge-ready; N1–N3 can follow as
documented cleanups. Security/bounds/escaping and the no-JS/print/fallback paths are otherwise
sound in this scope.

## Final targeted re-review of B1, B2 and N2 — APPROVED

Re-checked only the stated corrections and their immediate contracts, read-only. No repository,
CMS, database or bundle was modified.

- **B1 — fixed.** `renderReadout` emits no `.chart-readout-unit` element and the CSS
  `::before` rule is gone. Every prepared display cell in the probed single-series and calendar
  v2 payloads ends with its prepared unit exactly once (`1,8 %`, no duplicate); the comparison
  payloads share the same `_display` boundary, checked by inspection.
  `data-unit` is present on each readout row for the tests that inspect it. A scratch rebuild of
  `tools/charts/src/adapter.js` with the vendored `node_modules` produced byte-identical
  `prumo-charts.min.js`, sha256 `dd5f30bf…df10`, matching the manifest and NOTICE; the minified
  bundle contains the new `setAttribute("data-unit", …)` and no readout-unit class. The served URL
  is content-fingerprinted, so no stale bundle path remains.
- **B2 — fixed.** `ordem` is parsed with the same raw-count/syntax guard as `s` before the DB
  handle; malformed or 49-value metadata returns the generic 404. `preserve_order` intersects
  with the current `s`, keeps retained refs in prior order, and appends new refs in submission
  order; `retire` runs after it. Search renders bounded hidden `ordem` fields from
  `page.selection`. A real form-order probe with one page per result reproduced the original
  reversal (`page 3` native `s` order `[WORLD, HICP]`) and now opens
  `[HICP, WORLD]`; the resulting Caderno cards and chart series are in that same retained order.
  Unchecking a reference drops it even when its id remains in `ordem`.
- **N2 — fixed.** Clearing the selection resets to `ChartSettings()` after strict chart parsing;
  both `grafico=off` and the original `grafico=on&g=HICP&limpar=selecao` repro now render no
  hidden chart field at all, so a new selection chooses the default chart.

Bounded probes: the four new discovery tests pass; the whole
`tests/app/test_discovery_selection.py` file passes (26 tests); `tests/test_typography.py`
passes (18); the page-transition, Caderno-order, payload-unit and N2 probes pass. N1/N3 remain
non-blocking and unchanged, and were not re-expanded. **APPROVED.**
