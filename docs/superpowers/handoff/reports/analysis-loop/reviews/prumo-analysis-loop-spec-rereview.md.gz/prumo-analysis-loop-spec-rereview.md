# Re-review — Prumo analysis loop L1–L3 (spec, integrated fixes)

Status: **APPROVED**

Scope: read-only re-review of the uncommitted worktree on `93ce855` (base `3b29735`),
9 changed files. No repository files were modified. Focused Python/browser probes only;
no full suite. Prior report: `prumo-analysis-loop-independent-spec-review.md`.

## Prior blocking findings — closed

### 1. Primary/derived and single-CMS disclosure

- `app/templates/series.html:2` imports `chart_meta`; `:28` renders
  `{% call chart_shell(...) %}{{ source_metadata() }}{% endcall %}` on the payload path and
  `{% call chart_meta() %}{{ source_metadata() }}{% endcall %}` on the static-SVG fallback.
- `app/templates/derived.html:2`, `:29` mirror the same two branches; the fallback base-series
  link is now real (`derived.html:27`).
- `app/templates/cms_chart.html:2`, `:36` does the same for the reachable legacy/single branch
  (`page.chart_payload` false), with `source_metadata()` at `:30-35`.
- `app/templates/_chart.html:4-9` is the single `chart_meta` boundary (`details.chart-meta`,
  summary `Séries, eixos e fontes`); `:25` only injects it into `chart_shell` when a caller
  block exists, so live payload consumers get it and no caller is silently dropped.
- Live route inspection: `/comparar/<slug>` and `/graficos/<slug>` both render
  `cms_chart.html` (`app/main.py:311`, `app/cms_routes.py:65`); `compare.html` /
  `compare_countries.html` remain unrouted and were not resurrected.

Focused probe (forced `interactive.build_payload -> None`):

- `/graficos/comparacao-revista` legacy pair: 200; `details.chart-meta` count 1; inside
  `.chart-shell` count 0 (direct figure child); exact summary present; source link present;
  no `chart-data` script and no bundle.
- `/series/<HICP>` and `/calculadas/<DERIVED>`: 200; one `details.chart-meta` each, outside
  shell, source link present, no `chart-data`/bundle.

New assertion `tests/app/test_analytical_pages.py:69-72` requires exactly one adjacent
`details.chart-meta`, the exact summary and at least one source link on every parameterized
route. That covers all five live payload routes (primary, derived, two CMS charts, comparison).

### 2. Fallback print disclosure outside `.chart-shell`

- `static/css/chart-inspector.css:112-155` now scopes every rule as `details.chart-meta`
  (screen margin/summary at `:112-121`; print at `:138-155`), including
  `::details-content { content-visibility: visible !important; display: block !important; }`
  and the direct-child display fallback. No `.chart-shell` prefix remains.
- `app/templates/base.html:14` loads `chart-inspector.css` globally, so CMS pages, previews,
  primary/derived pages and the notebook all receive the print rules.
- Fallback markup is outside the shell by construction: `_cms_blocks.html:90-93`,
  `_cms_analysis.html:26`, `_notebook_chart.html:37-40`, plus the three new branches above.

Real-route browser probe (`/graficos/comparacao-revista`, legacy pair, payload forced absent,
Chromium, actual CSS): details is outside the shell (inside-shell count 0), has no `open`
attribute on screen and its note is not visible; under print media the summary computes
`display: none` and `.chart-source-note` is visible with a 952px-wide box. The same CSS was
also exercised on a standalone outside-shell `details` with identical results. Finding closed.

## L2 native first-visit selection — closed

- `app/templates/search.html:44-72`: compact selection section precedes `page.total` results
  (`:74`); the `Abrir caderno` submit at `:47` is rendered unconditionally and has no
  `disabled`; the selected-reference list/remove/update controls are inside the native
  `details.selection-review` (`:54-70`). A second, differently named open action follows the
  results at `:90` (`Abrir seleção no Caderno`).
- `static/css/discovery.css:28-40` keeps the tray in flow (margin/padding only; no
  sticky/fixed), so it cannot cover result actions at mobile widths; print hides it at
  `:125-128`.
- Server contracts unchanged (`app/main.py:227-232`, `254-257`; `app/discovery_selection.py`
  untouched): >48 raw or malformed references return the generic 404 before opening the DB;
  13–48 unique references are retained and rendered with the count/limit notice; `acao=abrir`
  redirects only at `len(selection) <= 12`; settings and unavailable-reference paths unchanged.
  `selection_can_open` remains a model field but is no longer used to disable the native
  control.

Real-browser probe of the one `discovery-form`:

- First visit: two open submits rendered, first `is_enabled()` true. Checking two result
  checkboxes and one click navigated to
  `/caderno?s=worldbank.gdp_growth.US&s=ine.unemployment_monthly.PT` — both references, DOM
  order, no intermediate refresh or JS.
- 13-reference response: heading `13 referências selecionadas`, open submit enabled; unchecking
  the current-page `HICP` checkbox and clicking open navigated to `/caderno` with 12 `s`
  references — server accepted the reduced set immediately after the refusal state.
- Empty open (`acao=abrir` with no refs) 303s to `/caderno`, which renders the empty notebook
  state 200; consistent with the updated “always available, even on a first visit” rule.

## Binding plan comparison

The only plan change is line 55's L2 paragraph, and it matches the implementation: compact
tray before results, native remove submits inside a review disclosure, no mobile overlap,
server-response count with the “new checks travel on submission” note, always-enabled open
action on first visit/over-limit with server-side validation, second open action after
results, no JavaScript. L1 line 39 is unchanged and is now satisfied by the three template
branches plus global print selectors above.

## Verification

- `/home/joao/projects/prumo-pipeline/.venv-ci/bin/python -m pytest
  tests/app/test_analytical_pages.py tests/app/test_discovery_selection.py -q`
  → **33 passed** in 29.11s (includes the 11 analytical-page tests, among them the browser
  geometry/print/no-JS test).
- No source, CMS, worker or deploy files were touched by the worktree diff (`git diff --stat`:
  templates, CSS, two tests, plan only). No repository edits by this review.

## Non-blocking note

The new analytical assertion covers the payload routes only; the static-SVG fallback branches
(primary, derived, `cms_chart` legacy, `_cms_blocks`, `_cms_analysis`, notebook) have no
automated DOM/print regression assertion. Their behavior is correct and was verified by the
focused probes above, but a future markup refactor could drop the `chart_meta` call without a
test failing. This is test-coverage debt, not a remaining spec gap.
