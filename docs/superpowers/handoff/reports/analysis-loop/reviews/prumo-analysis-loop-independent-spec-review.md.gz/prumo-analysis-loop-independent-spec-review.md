# Independent SPEC review — Prumo analysis loop L1–L3

Status: **REQUEST_CHANGES**

Scope: read-only review of `3b29735..HEAD` (`93ce855`) against
`docs/superpowers/plans/2026-11-26-analysis-loop-roadmap.md`, especially binding
resolutions lines 35–61. No repository files were modified. No tests or services were run.

## Blocking findings

### 1. Primary/derived (and legacy comparison) consumers do not get the metadata disclosure

- `app/templates/_chart.html:25` only emits `details.chart-meta` when a caller block is
  supplied.
- `app/templates/series.html:25` and `app/templates/derived.html:26` call
  `chart_shell(page, ...)` without `{% call %}`, so their rendered HTML has no
  `details class="chart-meta"` and no summary `Séries, eixos e fontes`. Their source
  metadata remains a plain `<figcaption>` (`series.html:26`, `derived.html:27`).
- The same omission exists in `app/templates/compare.html:27`,
  `compare_countries.html:42` and the legacy branch of `cms_chart.html:30`.

Binding resolution line 39 explicitly requires the canvas → inspector → compact legend →
native metadata disclosure order to cover "primary and derived consumers". The actual diff
did not touch those templates' metadata boundary.

Reproducible: request a detail page such as `/series/<published-id>` or
`/calculadas/<key>` and inspect the chart figure; `details.chart-meta` is absent while the
old `figcaption` remains. The focused tests in `tests/app/test_analytical_pages.py` check
shell child order for these pages but never assert the disclosure exists, so they do not
catch this.

### 2. Fallback metadata disclosure is not opened in print

- `app/templates/_cms_analysis.html:26`, `app/templates/_cms_blocks.html:90-93` and
  `app/templates/_notebook_chart.html:38-40` render `chart_meta` **outside** a
  `.chart-shell` when `chart_payload` is falsy (the static/fallback SVG branch).
- `static/css/chart-inspector.css:138-155` scopes every print-open rule to
  `.chart-shell details.chart-meta`, including the `::details-content` and
  `> *:not(summary)` overrides. A `details.chart-meta` outside `.chart-shell` therefore
  stays closed in print; its content is not printed, contrary to binding line 39.

Reproducible: render any of the fallback branches (CMS block/page preview whose
`chart.chart_payload` is falsy, Caderno panel without a payload) and emulate print media.
The `<details>` has no `open` attribute and no matching print selector, so the disclosure
content remains hidden. The current print test only covers `/comparar/publicado`, whose
payload path puts the disclosure inside `.chart-shell`.

## Reviewed without blocking findings

- L2 native discovery form: one form owner `discovery-form`, search landmark confined to
  the query/filter group, result checkboxes/tray/pager in the same form, search/filter
  resets page, pager carries `pagina`, off-page refs are hidden inputs only, visible
  selected rows are checkbox-only (no duplicate hidden `s`), remove/clear/open are named
  native submits, raw ceiling 48 rejects before DB work, 13–48 refs are retained, and
  `abrir` is refused above 12. Chart settings round-trip through `frequencia_grafico`;
  notebook `frequencia` handoff remains correct.
- L3 catalogue matching adds only the resolved theme title in
  `_catalogue_haystack`; `_search_haystack` and `reads.search` remain on the old bounded
  phrase path.
- No source/CMS writes, cookies, public comparison configuration, schema/migration
  changes or rounding/formatter changes were found in the reviewed diff.
