"""Controller's real-network Task14 acceptance, f0nix egress, isolated local DB.
No fixture HTTP, no private verifier registry writes, no secret in public artifacts.
"""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl
from decimal import Decimal
import base64
import hashlib
import json
import shlex
import subprocess
import time

from ingest.db import open_db
from ingest.http import HttpResult
from ingest.rawstore import RawStore
from ingest.registry import load_registry, sync_registry
from ingest.sources.fred import FredSource
from ingest.verifiers import register_verifier
from ingest.verifiers.fred import FredVerifier, read_table_page
from ingest.verify import run_with_refetch

ROOT=Path('/home/joao/.hermes/cache/scratch/prumo-t14-live-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S'))
ROOT.mkdir(parents=True)
KEY=Path('/home/joao/projects/prumo-pipeline/.fred_api_key').read_text().strip()
REMOTE='''import sys,json,base64,urllib.request,urllib.parse,urllib.error
p=json.load(sys.stdin)
u=p['url']
if p['params']: u+='?'+urllib.parse.urlencode(p['params'])
req=urllib.request.Request(u,headers={'User-Agent':'prumo-ingest/1.0 (+https://cae.joao.date)',**(p['headers'] or {})})
try:
 with urllib.request.urlopen(req,timeout=12) as r:
  b=r.read(2_000_001)
  if len(b)>2_000_000:raise ValueError('body cap')
  out=dict(status=r.status,url=r.url,body_b64=base64.b64encode(b).decode())
except urllib.error.HTTPError as e:
 b=e.read(2_000_001);out=dict(status=e.code,url=e.url,body_b64=base64.b64encode(b).decode())
except Exception as e:out=dict(error_type=type(e).__name__)
print(json.dumps(out))
'''
class F0nixHttp:
 def __init__(self):self.records=[];self.start=time.monotonic();self.last=0
 def get(self,url,params=None,headers=None,timeout=None):
  if len(self.records)>=48 or time.monotonic()-self.start>180:raise TimeoutError('controller total network budget')
  wait=1-(time.monotonic()-self.last)
  if wait>0:time.sleep(wait)
  self.last=time.monotonic()
  seq=len(self.records)+1
  rec=dict(seq=seq,requested_url=url,params={k:v for k,v in (params or {}).items() if k!='api_key'},
           fetched_at=datetime.now(timezone.utc).isoformat(),egress='f0nix')
  t=time.monotonic()
  r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','f0nix','python3 -c '+shlex.quote(REMOTE)],
                   input=json.dumps(dict(url=url,params=params,headers=headers)),text=True,capture_output=True,timeout=20)
  rec['elapsed_s']=round(time.monotonic()-t,2)
  if r.returncode:
   rec['error_type']='SSHError';self.records.append(rec);raise RuntimeError('f0nix transport failure')
  d=json.loads(r.stdout)
  if 'error_type' in d:
   rec['error_type']=d['error_type'];self.records.append(rec);raise RuntimeError('f0nix '+d['error_type'])
  b=base64.b64decode(d['body_b64'],validate=True)
  if KEY.encode() in b:raise RuntimeError('credential echo refused')
  parts=urlsplit(d['url']);public=urlunsplit((parts.scheme,parts.netloc,parts.path,urlencode([(k,v) for k,v in parse_qsl(parts.query) if k!='api_key']),''))
  rec.update(status=d['status'],final_url=public,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),body_file=f'response-{seq:02d}.body')
  (ROOT/rec['body_file']).write_bytes(b);self.records.append(rec)
  (ROOT/'request-manifest.json').write_text(json.dumps(self.records,indent=2)+'\n')
  print(json.dumps(dict(request=seq,status=d['status'],endpoint=url,bytes=len(b))),flush=True)
  return HttpResult(status=d['status'],url=d['url'],body=b)

specs=[s for s in load_registry(Path('/home/joao/projects/prumo-pipeline/registry/core.yaml')) if s.source.name=='fred' and s.active]
assert len(specs)==12 and len({s.native_code for s in specs})==12
assert all(not s.source.redistribution_ok for s in specs)
verifier=FredVerifier();register_verifier(verifier)
store=RawStore(ROOT/'raw');db=open_db(ROOT/'live.sqlite3');sync_registry(db,specs)
http=F0nixHttp();start=time.monotonic()
try:
 result=run_with_refetch(db,store,FredSource(api_key=KEY),verifier,specs,http,max_attempts=1,size=120)
 q=lambda sql,*args:db.conn.execute(sql,args).fetchall()
 report=dict(kind='fresh-network-controller-acceptance',egress='f0nix',scratch_root=str(ROOT),
             state=result.state,run_id=result.run_id,n_written=result.n_written,n_quarantined=result.n_quarantined,
             served=q('SELECT COUNT(*) FROM served_observation')[0][0],
             per_series=q('SELECT series_id,COUNT(*),MIN(period),MAX(period) FROM observation WHERE dataset_run_id=? GROUP BY series_id',result.run_id),
             quarantine=q('SELECT reason,COUNT(*) FROM quarantine WHERE dataset_run_id=? GROUP BY reason',result.run_id),
             verification=q('SELECT seed,sample_size,passed FROM verification WHERE dataset_run_id=?',result.run_id),
             comparison_totals=q('SELECT COUNT(*),SUM(match) FROM verification_item'),
             raw_fetch_count=q('SELECT COUNT(*) FROM raw_fetch'),request_count=len(http.records),elapsed_s=round(time.monotonic()-start,2))
 rows=q('SELECT series_id,period,expected_text,observed_text,observed_unit,evidence_url,evidence_sha256 FROM verification_item')
 by_id={s.id:s for s in specs};decoded={};replayed=0
 for sid,period,expected,observed,unit,url,sha in rows:
  blob=store.load(store.root/'verify-fred'/sha[:2]/sha)
  assert hashlib.sha256(blob).hexdigest()==sha
  doc=json.loads(blob);assert doc['schema']=='fred-table-evidence' and doc['version']==1
  rec=doc['table'];assert rec['status']==200 and rec['url']==url
  original=base64.b64decode(rec['body_b64'],validate=True)
  assert any(r.get('sha256')==hashlib.sha256(original).hexdigest() and r.get('final_url')==url and r.get('status')==200 for r in http.records)
  if sha not in decoded:decoded[sha]=read_table_page(original,by_id[sid].native_code,by_id[sid])
  actual_unit,values=decoded[sha]
  assert actual_unit==unit==by_id[sid].unit
  assert values[period]==observed and Decimal(expected)==Decimal(observed)
  replayed+=1
 report['offline_comparisons_replayed']=replayed;report['distinct_evidence_envelopes']=len(decoded)
 # Explicit checks of credentials in every persisted artifact, not just test assertions.
 assert all(KEY.encode() not in p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and p.suffix not in ('.sqlite3',))
 # SQLite WAL may contain raw data; the key must be absent everywhere.
 assert KEY.encode() not in (ROOT/'live.sqlite3').read_bytes()
 (ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print('REPORT',json.dumps(report,indent=2),flush=True)
 assert result.state=='verified'
 assert {r[0] for r in report['per_series']}=={s.id for s in specs}
 assert report['comparison_totals']==[(120,120)]
 assert report['offline_comparisons_replayed']==120 and len(decoded)==12 and report['served']==0
except Exception as e:
 safe=dict(error_type=type(e).__name__,root=str(ROOT),request_count=len(http.records),elapsed_s=round(time.monotonic()-start,2))
 (ROOT/'failure.json').write_text(json.dumps(safe,indent=2)+'\n')
 print('CONTROLLER_FAILURE',json.dumps(safe),flush=True)
 raise
finally:
 (ROOT/'request-manifest.json').write_text(json.dumps(http.records,indent=2)+'\n')
 db.close()
