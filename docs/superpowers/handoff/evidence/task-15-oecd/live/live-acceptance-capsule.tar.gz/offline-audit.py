"""Controller audit capsule replay. Run from the Prumo repo with its test environment.

python /path/to/offline-audit.py /path/to/extracted/capsule
No HTTP. SQLite is opened read-only; original scratch paths are resolved by stored hashes.
"""
import base64
import hashlib
import json
import sqlite3
import sys
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

sys.path.insert(0, str(Path.cwd()))
from ingest.models import SeriesSpec
from ingest.sources import RawResponse
from ingest.sources.oecd import OecdSource
from ingest.verifiers.oecd import read_csv_evidence

root = Path(sys.argv[1]).resolve()
manifest = json.loads((root / "capsule-manifest.json").read_text())
for entry in manifest["files"]:
    file = root / entry["path"]
    assert file.is_file() and not file.is_symlink()
    data = file.read_bytes()
    assert len(data) == entry["bytes"]
    assert hashlib.sha256(data).hexdigest() == entry["sha256"]
specs = [SeriesSpec.model_validate(s) for s in json.loads((root / "registry-snapshot.json").read_text())]
by_id = {s.id: s for s in specs}
summary = json.loads((root / "summary.json").read_text())
wire = json.loads((root / "wire.json").read_text())
connection = sqlite3.connect((root / "acceptance.sqlite3").as_uri() + "?mode=ro", uri=True)
try:
    responses = []
    for url, params, status, sha in connection.execute("SELECT url,params_json,http_status,sha256 FROM raw_fetch ORDER BY id"):
        body = (root / "raw" / "oecd" / sha[:2] / sha).read_bytes()
        assert hashlib.sha256(body).hexdigest() == sha
        assert status == 200
        responses.append(RawResponse(url=url, params=json.loads(params), status=status, body=body))
    parsed = OecdSource().parse(specs, responses)
    recovered = 0
    for sid, rows in parsed.items():
        expected = {(r.period_raw, r.value_raw.strip(), r.flag_raw) for r in rows if r.value_raw is not None}
        actual = set(connection.execute("SELECT period,value_text,status_flag FROM observation WHERE series_id=?", (sid,)))
        assert expected == actual
        recovered += len(actual)
    items = list(connection.execute("SELECT series_id,period,evidence_url,evidence_sha256,expected_text,observed_text,observed_unit,observed_flag,match FROM verification_item"))
    bundles = {}
    for sid, period, url, sha, expected_text, token, unit, flag, match in items:
        if sha not in bundles:
            data = (root / "raw" / "verify-oecd" / sha[:2] / sha).read_bytes()
            assert hashlib.sha256(data).hexdigest() == sha
            doc = json.loads(data)
            assert doc["schema"] == "oecd-csv-evidence" and doc["version"] == 1
            record = doc["csv"]
            csv_body = base64.b64decode(record["body_b64"], validate=True)
            originals = [r for r in wire if r["url"] == record["url"]]
            assert len(originals) == 1 and record["status"] == originals[0]["status"] == 200
            assert hashlib.sha256(csv_body).hexdigest() == originals[0]["sha256"]
            q = parse_qs(urlsplit(record["url"]).query)
            got_unit, vals = read_csv_evidence(csv_body, by_id[sid].native_code, by_id[sid], start=q["startPeriod"][0], end=q["endPeriod"][0])
            bundles[sha] = (record["url"], got_unit, vals)
        got_url, got_unit, vals = bundles[sha]
        assert got_url == url and got_unit == unit and vals[period] == (token, flag)
        assert match == 1 and Decimal(token) == Decimal(expected_text)
    assert recovered == summary["all_publisher_tokens_recovered"]
    assert len(items) == summary["sampled_comparisons_recovered"]
    assert len(bundles) == summary["evidence_bundles_recovered"]
    assert set(parsed) == {i[0] for i in items} == set(by_id)
    assert connection.execute("SELECT COUNT(*) FROM served_observation").fetchone()[0] == 0
    print(json.dumps({"files_hashed": len(manifest["files"]), "raw_responses": len(responses), "observations_recovered": recovered, "sample_comparisons": len(items), "evidence_bundles": len(bundles), "served": 0, "network_used": False, "state": "passed"}, indent=2))
finally:
    connection.close()
