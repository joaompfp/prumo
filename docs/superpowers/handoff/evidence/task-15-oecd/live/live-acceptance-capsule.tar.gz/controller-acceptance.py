"""Controller OECD full-history acceptance with real f0nix network egress.

No deployment, remote files, credentials or production database access. Publisher bodies are
kept verbatim; wire.json and summary.json are explicitly controller-created audit records.
"""
import base64
import hashlib
import json
import shlex
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs
from urllib.parse import urlsplit

sys.path.insert(0, "/home/joao/projects/prumo-pipeline")
from ingest.db import open_db
from ingest.http import HttpResult
from ingest.rawstore import RawStore
from ingest.registry import load_registry, sync_registry
from ingest.sources import RawResponse
from ingest.sources.oecd import OecdSource
from ingest.verifiers import register_verifier
from ingest.verifiers.oecd import OecdVerifier, read_csv_evidence
from ingest.verify import run_with_refetch
from tests.ingest.live_bounds import hard_deadline

ROOT = Path(tempfile.mkdtemp(prefix="prumo-oecd-acceptance-", dir="/home/joao/.hermes/cache/scratch"))
REGISTRY = Path("/home/joao/projects/prumo-pipeline/registry/core.yaml")
REMOTE = '''import base64, json, signal, sys, urllib.request, urllib.error, urllib.parse
from datetime import datetime, timezone
p=json.loads(sys.stdin.read())
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**k): return None
def abort(*a): raise TimeoutError("remote whole-request deadline")
signal.signal(signal.SIGALRM,abort)
signal.setitimer(signal.ITIMER_REAL,p["timeout"])
url=p["url"]
if p["params"]:
    url += ("&" if "?" in url else "?")+urllib.parse.urlencode(p["params"])
req=urllib.request.Request(url,headers={"User-Agent":"prumo-ingest/1.0 (+https://cae.joao.date)",**p["headers"]})
ts=datetime.now(timezone.utc).isoformat()
try:
    try: r=urllib.request.build_opener(NoRedirect()).open(req,timeout=p["timeout"])
    except urllib.error.HTTPError as e: r=e
    with r:
        b=r.read(5242881)
        if len(b)>5242880: raise ValueError("publisher body exceeds controller 5MiB limit")
        print(json.dumps({"status":r.status,"url":r.geturl(),"body_b64":base64.b64encode(b).decode(),"requested_at":ts,"content_type":r.headers.get("Content-Type")}))
finally:
    signal.setitimer(signal.ITIMER_REAL,0)
'''

class F0nixHttp:
    def __init__(self):
        self.started = time.monotonic()
        self.last = 0.0
        self.records = []

    def get(self, url, params=None, headers=None, timeout=None):
        remaining = 180 - (time.monotonic() - self.started)
        if len(self.records) >= 18 or remaining <= 3:
            raise RuntimeError("controller whole-phase request/deadline budget exhausted")
        time.sleep(max(0, 4.5 - (time.monotonic() - self.last)))
        self.last = time.monotonic()
        remaining = 180 - (time.monotonic() - self.started)
        per_request = min(12, remaining - 1)
        if per_request <= 0:
            raise TimeoutError("controller phase deadline expired before dispatch")
        payload = {"url": url, "params": params or {}, "headers": headers or {}, "timeout": per_request}
        proc = subprocess.run(["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", "f0nix", "python3", "-c", shlex.quote(REMOTE)], input=json.dumps(payload), text=True, capture_output=True, timeout=min(16, remaining))
        if proc.returncode:
            raise RuntimeError(f"f0nix HTTP bridge failed ({proc.returncode}): {proc.stderr[-1000:]}")
        rec = json.loads(proc.stdout)
        body = base64.b64decode(rec.pop("body_b64"), validate=True)
        name = f"wire-{len(self.records)+1:02d}.body"
        (ROOT / name).write_bytes(body)
        rec.update({"file": name, "requested_url": url, "params": params or {}, "headers": headers or {}, "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(), "egress": "f0nix", "record_kind": "controller-wire-record-original-publisher-body"})
        self.records.append(rec)
        (ROOT / "wire.json").write_text(json.dumps(self.records, indent=2))
        return HttpResult(status=rec["status"], url=rec["url"], body=body)

specs = [s for s in load_registry(REGISTRY) if s.source.name == "oecd" and s.active]
assert len(specs) == 6
assert all(s.source.verifiable and not s.source.redistribution_ok for s in specs)
(ROOT / "registry-snapshot.json").write_text(json.dumps([s.model_dump(mode="json") for s in specs], indent=2))
db = open_db(ROOT / "acceptance.sqlite3")
store = RawStore(ROOT / "raw")
http = F0nixHttp()
summary = {"kind": "controller-created-live-acceptance-not-deployment", "started_at": datetime.now(timezone.utc).isoformat(), "registry_sha256": hashlib.sha256(REGISTRY.read_bytes()).hexdigest(), "egress": "f0nix", "root": str(ROOT), "max_physical_requests": 18, "whole_network_deadline_s": 180, "per_remote_request_deadline_s": 12, "minimum_request_interval_s": 4.5, "retries": 0, "max_dataset_attempts": 1}
try:
    sync_registry(db, specs)
    verifier = OecdVerifier()
    register_verifier(verifier)
    with hard_deadline(180):
        result = run_with_refetch(db, store, OecdSource(), verifier, specs, http, size=120, max_attempts=1)
    summary.update({"state": result.state, "run_id": result.run_id, "n_written": result.n_written, "n_quarantined": result.n_quarantined, "network_elapsed_s": round(time.monotonic()-http.started, 3), "http_responses": len(http.records)})
    per_series = db.conn.execute("SELECT series_id,COUNT(*),MIN(period),MAX(period) FROM observation WHERE dataset_run_id=? GROUP BY series_id ORDER BY series_id", (result.run_id,)).fetchall()
    sample = db.conn.execute("SELECT sample_size,passed FROM verification WHERE dataset_run_id=?", (result.run_id,)).fetchall()
    served = db.conn.execute("SELECT COUNT(*) FROM served_observation").fetchone()[0]
    quarantine = db.conn.execute("SELECT reason,COUNT(*) FROM quarantine GROUP BY reason").fetchall()
    summary.update({"series": per_series, "verification": sample, "served": served, "quarantines": quarantine})
    assert result.state == "verified", summary
    assert {r[0] for r in per_series} == {s.id for s in specs}
    assert served == 0
    assert sample == [(120, 1)]
    assert len(http.records) == 12 and all(r["status"] == 200 for r in http.records)
    # Reconstruct collector inputs only from its newly archived raw_fetch records.
    raws = db.conn.execute("SELECT url,params_json,http_status,path FROM raw_fetch WHERE dataset_run_id=? ORDER BY id", (result.run_id,)).fetchall()
    responses = [RawResponse(url=url, params=json.loads(params), status=status, body=store.load(Path(path))) for url, params, status, path in raws]
    assert len(responses) == 6
    expected = OecdSource().parse(specs, responses)
    archived_tokens = 0
    for spec in specs:
        actual = dict(db.conn.execute("SELECT period,value_text FROM observation WHERE dataset_run_id=? AND series_id=?", (result.run_id, spec.id)).fetchall())
        good = {row.period_raw: row.value_raw.strip() for row in expected[spec.id] if row.value_raw is not None}
        assert actual == good
        archived_tokens += len(good)
    # All sampled value/unit/flag fields recover from original CSV bytes, without HTTP.
    items = db.conn.execute("SELECT series_id,period,evidence_url,evidence_sha256,expected_text,observed_text,observed_unit,observed_flag,match FROM verification_item").fetchall()
    by_id = {s.id: s for s in specs}
    bundles = {}
    for sid, period, url, sha, expected_text, token, unit, flag, match in items:
        if sha not in bundles:
            blob = store.load(store.root / "verify-oecd" / sha[:2] / sha)
            assert hashlib.sha256(blob).hexdigest() == sha
            envelope = json.loads(blob)
            assert envelope["schema"] == "oecd-csv-evidence" and envelope["version"] == 1
            rec = envelope["csv"]
            body = base64.b64decode(rec["body_b64"], validate=True)
            wire = [r for r in http.records if r["url"] == rec["url"]]
            assert len(wire) == 1 and wire[0]["status"] == rec["status"] == 200
            assert hashlib.sha256(body).hexdigest() == wire[0]["sha256"]
            query = parse_qs(urlsplit(rec["url"]).query)
            got_unit, vals = read_csv_evidence(body, by_id[sid].native_code, by_id[sid], start=query["startPeriod"][0], end=query["endPeriod"][0])
            bundles[sha] = (rec["url"], got_unit, vals)
        got_url, got_unit, values = bundles[sha]
        assert got_url == url and got_unit == unit and values[period] == (token, flag)
        assert match == 1 and Decimal(expected_text) == Decimal(token)
    assert len(items) == 120 and {i[0] for i in items} == set(by_id)
    assert len(bundles) == 6
    summary.update({"all_publisher_tokens_recovered": archived_tokens, "sampled_comparisons_recovered": len(items), "evidence_bundles_recovered": len(bundles), "offline_replay": "passed"})
except Exception as exc:
    summary["failure"] = f"{type(exc).__name__}: {exc}"
    raise
finally:
    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    db.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    db.close()
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
